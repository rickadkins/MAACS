maacs file for second week lectures
===============================

This repository contains in addition to the codes for Project 1 the maacs
dataset needed in the second week lectures

***
To load the maacs dataset, just save it in your working directory
or fork this project, and "load" it using:
```{r}
load("maacs.rda")
```
***

The maacs data set was created using the following data sets:

maacs_env.rds, found at
https://github.com/jtleek/modules/blob/master/04_ExploratoryAnalysis/PlottingLattice/maacs_env.rds

and

problem3.rda, found at
https://github.com/jtleek/jhsph753and4/blob/master/lectures/EBDA/problem3.rda
